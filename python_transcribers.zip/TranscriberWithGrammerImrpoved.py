import os
import sys
import json
import shutil
import time
from faster_whisper import WhisperModel
from pydub import AudioSegment
import language_tool_python # Added for grammar and spelling correction

def split_audio(input_path, segment_duration_sec):
    audio = AudioSegment.from_file(input_path)
    segment_paths = []
    output_dir = os.path.join(os.path.dirname(input_path), "segments")
    os.makedirs(output_dir, exist_ok=True)

    for i in range(0, len(audio), segment_duration_sec * 1000):
        segment = audio[i:i + segment_duration_sec * 1000]
        
        # --- Pre-processing Step: Noise Reduction (Conceptual Placeholder) ---
        # For more effective noise reduction, consider using a dedicated library like 'noisereduce'.
        # This typically involves converting the pydub AudioSegment to a numpy array,
        # applying noise reduction, and then converting it back to an AudioSegment.
        #
        # Example (requires 'pip install noisereduce numpy scipy'):
        # import noisereduce as nr
        # import numpy as np
        #
        # if segment.sample_width == 1: # 8-bit
        #     dtype = np.int8
        # elif segment.sample_width == 2: # 16-bit
        #     dtype = np.int16
        # elif segment.sample_width == 4: # 32-bit
        #     dtype = np.int32
        # else:
        #     # Handle other sample widths or raise error
        #     dtype = np.int16 # Default or error as appropriate
        #
        # samples = np.array(segment.get_array_of_samples(), dtype=dtype)
        # sample_rate = segment.frame_rate
        #
        # # Apply noise reduction (parameters may need tuning based on noise type)
        # # You might need to first estimate noise from a silence part if available.
        # # For demonstration, a very basic call:
        # # reduced_noise_samples = nr.reduce_noise(y=samples, sr=sample_rate)
        #
        # # Convert back to AudioSegment:
        # # segment = AudioSegment(reduced_noise_samples.tobytes(), 
        # #                        frame_rate=sample_rate, 
        # #                        sample_width=segment.sample_width, 
        # #                        channels=segment.channels)
        # -------------------------------------------------------------------
        
        segment_path = os.path.join(output_dir, f"segment_{i//1000:03d}.wav")
        segment.export(segment_path, format="wav")
        segment_paths.append((segment_path, i // 1000))

    return segment_paths, output_dir

def correct_text_post_processing(text, lang_code=None):
    """
    Applies grammar and spelling correction to the given text using LanguageTool.
    Requires 'language_tool_python' to be installed (pip install language_tool_python).
    
    Args:
        text (str): The text to be corrected.
        lang_code (str, optional): The language code (e.g., 'en-US', 'sw').
                                   If None, LanguageTool attempts auto-detection.
    Returns:
        str: The corrected text.
    """
    try:
        # Initialize LanguageTool. For better accuracy, explicitly pass the language.
        # For mixed English/Swahili, you might need to handle language detection per segment
        # or use a tool that supports multilingual grammar checking.
        # LanguageTool might need to download language data on first run.
        # For general English correction, 'en-US' is a good default.
        # For Swahili, 'sw' might be an option if available in your LanguageTool version.
        tool = language_tool_python.LanguageTool(lang_code if lang_code else 'en-US')
        
        matches = tool.check(text)
        corrected_text = language_tool_python.utils.correct(text, matches)
        tool.close() # Close the tool to release resources
        return corrected_text
    except Exception as e:
        print(f"Error during text post-processing (LanguageTool): {e}", file=sys.stderr)
        return text # Return original text on error if an error occurs

def main():
    if len(sys.argv) < 4:
        print("Usage: whisper_transcriber.py <audioFilePath> <modelType> <segmentDurationSec> [useTranslate] [isoCodeLanguage] [outputJsonPath]", file=sys.stderr)
        sys.exit(1)

    audio_file = sys.argv[1]
    model_type = sys.argv[2]  # tiny, base, small, medium, large-v3
    segment_duration = int(sys.argv[3])
    use_translate = sys.argv[4].lower() == 'true' if len(sys.argv) > 4 else False
    language = sys.argv[5] if len(sys.argv) > 5 else None # e.g., 'sw' for Swahili, 'en' for English
    output_json_path = sys.argv[6] if len(sys.argv) > 6 else None

    if not os.path.isfile(audio_file):
        print("Audio file not found.", file=sys.stderr)
        sys.exit(1)

    start_time = time.time()

    print(f"Loading model '{model_type}'...")
    model = WhisperModel(model_type, device="cuda", compute_type="float16")

    transcripts = []
    detected_language = None

    segments, segment_dir = split_audio(audio_file, segment_duration)

    try:
        for path, offset in segments:
            segments_result, info = model.transcribe(
                path,
                language=language,
                task="translate" if use_translate else "transcribe"
            )

            detected_language = detected_language or info.language

            for segment in segments_result:
                original_text = segment.text
                
                # --- Post-processing Step: Grammar and Spelling Correction ---
                # Pass the detected language to LanguageTool if available for better accuracy.
                # If 'language' argument was provided, use that. Otherwise, use Whisper's detected_language.
                correction_lang = language if language else detected_language
                corrected_text = correct_text_post_processing(original_text, correction_lang)
                
                transcripts.append({
                    "Text": corrected_text,     # Use the corrected text
                    "OriginalText": original_text, # Keep original for comparison
                    "StartInSeconds": int(segment.start) + offset,
                    "EndInSeconds": int(segment.end) + offset
                })

        result = {
            "Transcripts": sorted(transcripts, key=lambda x: x["StartInSeconds"]),
            "DetectedLanguage": detected_language or "unknown"
        }

        # Print results to console
        print(json.dumps(result, indent=2, ensure_ascii=False))

        elapsed = round(time.time() - start_time, 2)
        print(f"\n🕒 Total transcription time: {elapsed} seconds")
        print(f"📝 Transcript segments: {len(result['Transcripts'])}")

        # Save to file if path was provided
        if output_json_path:
            output = {
                "Result": result,
                "ElapsedSeconds": elapsed
            }

            try:
                os.makedirs(os.path.dirname(output_json_path), exist_ok=True)
                with open(output_json_path, "w", encoding="utf-8") as f:
                    json.dump(output, f, indent=2, ensure_ascii=False)

                print(f"\n✅ Saved output to: {output_json_path}")
            except Exception as e:
                print(f"\n❌ Failed to save JSON output: {e}", file=sys.stderr)

    finally:
        shutil.rmtree(segment_dir, ignore_errors=True)

if __name__ == "__main__":
    main()