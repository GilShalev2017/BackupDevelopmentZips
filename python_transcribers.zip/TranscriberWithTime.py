import os
import sys
import json
import shutil
import time
from faster_whisper import WhisperModel
from pydub import AudioSegment

def split_audio(input_path, segment_duration_sec):
    """
    Splits an audio file into smaller segments of a specified duration.

    Args:
        input_path (str): The path to the input audio file.
        segment_duration_sec (int): The duration of each segment in seconds.

    Returns:
        tuple: A tuple containing:
            - list: A list of tuples, where each tuple contains (segment_path, offset_in_seconds).
            - str: The path to the directory where segments are saved.
    """
    audio = AudioSegment.from_file(input_path)
    segment_paths = []
    # Create a temporary directory for segments next to the input audio file
    output_dir = os.path.join(os.path.dirname(input_path), "segments_" + str(int(time.time())))
    os.makedirs(output_dir, exist_ok=True)

    for i in range(0, len(audio), segment_duration_sec * 1000):
        segment = audio[i:i + segment_duration_sec * 1000]
        # Format segment file names with leading zeros for sorting
        segment_path = os.path.join(output_dir, f"segment_{i//1000:03d}.wav")
        segment.export(segment_path, format="wav")
        segment_paths.append((segment_path, i // 1000)) # Store path and start offset

    return segment_paths, output_dir

def main():
    """
    Main function to handle audio transcription using Whisper.
    Processes audio in segments, prints transcription results to console,
    and optionally saves results to a JSON file.
    """
    # Check for correct number of command-line arguments
    if len(sys.argv) < 4:
        print("Usage: whisper_transcriber.py <audioFilePath> <modelType> <segmentDurationSec> [useTranslate] [isoCodeLanguage] [outputJsonPath]", file=sys.stderr)
        sys.exit(1)

    # Parse command-line arguments
    audio_file = sys.argv[1]
    model_type = sys.argv[2]  # tiny, base, small, medium, large-v3
    segment_duration = int(sys.argv[3])
    # Check if useTranslate argument is provided and convert to boolean
    use_translate = sys.argv[4].lower() == 'true' if len(sys.argv) > 4 else False
    # Check if language argument is provided
    language = sys.argv[5] if len(sys.argv) > 5 else None
    # Check if outputJsonPath argument is provided
    output_json_path = sys.argv[6] if len(sys.argv) > 6 else None

    # Validate if the audio file exists
    if not os.path.isfile(audio_file):
        print(f"Error: Audio file not found at '{audio_file}'.", file=sys.stderr)
        sys.exit(1)

    start_time = time.time()

    print(f"Loading Whisper model '{model_type}' (device: cuda, compute_type: float16)...")
    # Load Whisper model (automatically uses GPU if available, otherwise CPU)
    # compute_type="float16" for faster inference on compatible GPUs
    model = WhisperModel(model_type, device="cuda", compute_type="float16")
    print("Model loaded successfully.")

    transcripts = []
    detected_language = None

    print(f"Splitting audio into {segment_duration}-second segments...")
    segments, segment_dir = split_audio(audio_file, segment_duration)
    print(f"Generated {len(segments)} audio segments in '{segment_dir}'.")

    try:
        # Transcribe each segment
        for i, (path, offset) in enumerate(segments):
            print(f"Transcribing segment {i+1}/{len(segments)} (offset: {offset}s)...")
            segments_result, info = model.transcribe(
                path,
                language=language, # Use specified language or let Whisper detect
                task="translate" if use_translate else "transcribe" # Perform translation or transcription
            )

            # Detect language from the first segment if not specified
            detected_language = detected_language or info.language

            # Append transcribed segments to the list
            for segment in segments_result:
                transcripts.append({
                    "Text": segment.text.strip(), # Clean up whitespace
                    "StartInSeconds": round(segment.start + offset, 2), # Add offset and round
                    "EndInSeconds": round(segment.end + offset, 2)     # Add offset and round
                })

        # Sort transcripts by start time to ensure chronological order
        final_transcription_data = {
            "Transcripts": sorted(transcripts, key=lambda x: x["StartInSeconds"]),
            "DetectedLanguage": detected_language or "unknown"
        }

        elapsed_time = round(time.time() - start_time, 2)

        # Prepare the full output structure including elapsed time
        full_output = {
            "TranscriptionResult": final_transcription_data,
            "TranscriptionTimeInSeconds": elapsed_time
        }

        # Print results to console (pretty printed JSON)
        print("\n--- Transcription Result ---")
        print(json.dumps(full_output, indent=4, ensure_ascii=False))

        print(f"\n🕒 Total transcription time: {elapsed_time} seconds")
        print(f"📝 Total transcript segments: {len(final_transcription_data['Transcripts'])}")

        # Save to file if output_json_path was provided
        if output_json_path:
            try:
                # Ensure the output directory exists
                os.makedirs(os.path.dirname(output_json_path), exist_ok=True)
                with open(output_json_path, "w", encoding="utf-8") as f:
                    json.dump(full_output, f, indent=4, ensure_ascii=False)
                print(f"✅ Transcription saved to '{output_json_path}'")
            except IOError as e:
                print(f"Error: Could not save output to '{output_json_path}'. {e}", file=sys.stderr)
            except Exception as e:
                print(f"An unexpected error occurred while saving the file: {e}", file=sys.stderr)

    finally:
        # Clean up the temporary segment directory
        if os.path.exists(segment_dir):
            print(f"Cleaning up temporary segment directory: '{segment_dir}'")
            shutil.rmtree(segment_dir, ignore_errors=True)
        else:
            print(f"Temporary segment directory '{segment_dir}' not found for cleanup.")

if __name__ == "__main__":
    main()