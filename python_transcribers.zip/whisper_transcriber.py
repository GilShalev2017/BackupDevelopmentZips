import os
import sys
import json
import shutil
import time
from faster_whisper import WhisperModel
from pydub import AudioSegment

def split_audio(input_path, segment_duration_sec):
    audio = AudioSegment.from_file(input_path)
    segment_paths = []
    output_dir = os.path.join(os.path.dirname(input_path), "segments")
    os.makedirs(output_dir, exist_ok=True)

    for i in range(0, len(audio), segment_duration_sec * 1000):
        segment = audio[i:i + segment_duration_sec * 1000]
        segment_path = os.path.join(output_dir, f"segment_{i//1000:03d}.wav")
        segment.export(segment_path, format="wav")
        segment_paths.append((segment_path, i // 1000))

    return segment_paths, output_dir

def main():
    if len(sys.argv) < 4:
        print("Usage: whisper_transcriber.py <audioFilePath> <modelType> <segmentDurationSec> [useTranslate] [isoCodeLanguage] [outputJsonPath]", file=sys.stderr)
        sys.exit(1)

    audio_file = sys.argv[1]
    model_type = sys.argv[2]  # tiny, base, small, medium, large-v3
    segment_duration = int(sys.argv[3])
    use_translate = sys.argv[4].lower() == 'true' if len(sys.argv) > 4 else False
    language = sys.argv[5] if len(sys.argv) > 5 else None
    output_json_path = sys.argv[6] if len(sys.argv) > 6 else None

    if not os.path.isfile(audio_file):
        print("Audio file not found.", file=sys.stderr)
        sys.exit(1)

    start_time = time.time()

    print(f"Loading model '{model_type}'...")
    model = WhisperModel(model_type, device="cuda", compute_type="float16")

    transcripts = []
    detected_language = None

    segments, segment_dir = split_audio(audio_file, segment_duration)

    try:
        for path, offset in segments:
            segments_result, info = model.transcribe(
                path,
                language=language,
                task="translate" if use_translate else "transcribe"
            )

            detected_language = detected_language or info.language

            for segment in segments_result:
                transcripts.append({
                    "Text": segment.text,
                    "StartInSeconds": int(segment.start) + offset,
                    "EndInSeconds": int(segment.end) + offset
                })

        result = {
            "Transcripts": sorted(transcripts, key=lambda x: x["StartInSeconds"]),
            "DetectedLanguage": detected_language or "unknown"
        }

        # Print results to console
        print(json.dumps(result, indent=2, ensure_ascii=False))

        elapsed = round(time.time() - start_time, 2)
        print(f"\n🕒 Total transcription time: {elapsed} seconds")
        print(f"📝 Transcript segments: {len(result['Transcripts'])}")

        # Save to file if path was provided
        if output_json_path:
    output = {
        "Result": result,
        "ElapsedSeconds": elapsed
    }

    try:
        os.makedirs(os.path.dirname(output_json_path), exist_ok=True)
        with open(output_json_path, "w", encoding="utf-8") as f:
            json.dump(output, f, indent=2, ensure_ascii=False)

        print(f"\n✅ Saved output to: {output_json_path}")
    except Exception as e:
        print(f"\n❌ Failed to save JSON output: {e}", file=sys.stderr)

    finally:
        shutil.rmtree(segment_dir, ignore_errors=True)

if __name__ == "__main__":
    main()
