import openai

openai.api_key = "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"

output = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": "write me a script for hosting a conference on technology"}]
)

print(output)