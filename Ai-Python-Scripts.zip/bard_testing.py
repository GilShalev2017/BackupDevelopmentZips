# from bardapi import Bard
#
# token = 'bwgm43ztL4aJpMBN7b19TXaxVD0otXwtTJ_IC__aBlKOfSabFnc9r0VwCEg4wBZ_jDvong.'
# bard = Bard(token='bwgm43ztL4aJpMBN7b19TXaxVD0otXwtTJ_IC__aBlKOfSabFnc9r0VwCEg4wBZ_jDvong.')
# bard.get_answer("나와 내 동년배들이 좋아하는 뉴진스에 대해서 알려줘")['content']

from bardapi import Bard
import os
os.environ['_BARD_API_KEY']="bwgm43ztL4aJpMBN7b19TXaxVD0otXwtTJ_IC__aBlKOfSabFnc9r0VwCEg4wBZ_jDvong."

Bard().get_answer("Gil is the king")['content']