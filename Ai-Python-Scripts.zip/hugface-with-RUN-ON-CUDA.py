from transformers import AutoModelForCausalLM, AutoTokenizer
import os

local_model_path = "./gpt-j-6B"

# Load the model and tokenizer
model = AutoModelForCausalLM.from_pretrained(local_model_path).to(device)
tokenizer = AutoTokenizer.from_pretrained(local_model_path)

print("Model loaded on", device)

# Print model configuration as a check
print("Model configuration:")
print(model.config)

# Function to get answers from the model
def answer_question(question, context):
    prompt = f"Context: {context}\nQuestion: {question}\nAnswer:"
    inputs = tokenizer(prompt, return_tensors="pt", max_length=512, truncation=True).to(device)
    
    # Generate the answer
    output = model.generate(**inputs, max_length=200, do_sample=True, top_p=0.95, top_k=60)
    answer = tokenizer.decode(output[0], skip_special_tokens=True)
    
    # Extract the answer from the prompt
    answer = answer.split("Answer:")[-1].strip()
    
    return answer

# Example text and question
context = """
Artificial intelligence (AI) is intelligence demonstrated by machines, as opposed to the natural intelligence displayed by humans and animals.
Leading AI textbooks define the field as the study of "intelligent agents": any device that perceives its environment and takes actions that
maximize its chance of successfully achieving its goals.
"""
question = "What is artificial intelligence?"

# Get the answer to the question
answer = answer_question(question, context)

print(f"Question: {question}")
print(f"Answer: {answer}")