from transformers import pipeline, MarianMTModel, MarianTokenizer, GPT2TokenizerFast, GPTNeoForCausalLM, OPTForCausalLM

# Define the text and prompt
text = "Paris is the capital of France. Brad Pitt was seen in Los Angeles. The population of New York City is about 8 million."
prompt = "Find all the locations mentioned in the text."

# GPT-J for text generation
def use_gpt_j(text, prompt):
    model_name = "EleutherAI/gpt-j-6B"
    text_generator = pipeline("text-generation", model=model_name)
    full_prompt = f"{prompt} Text: {text}"
    result = text_generator(full_prompt, max_length=150, num_return_sequences=1)
    return result[0]['generated_text']

# GPT-NeoX for text generation
def use_gpt_neox(text, prompt):
    model_name = "EleutherAI/gpt-neox-20b"
    text_generator = pipeline("text-generation", model=model_name)
    full_prompt = f"{prompt} Text: {text}"
    result = text_generator(full_prompt, max_length=150, num_return_sequences=1)
    return result[0]['generated_text']

# OPT for text generation
def use_opt(text, prompt):
    model_name = "facebook/opt-175b"
    tokenizer = GPT2TokenizerFast.from_pretrained(model_name)
    model = OPTForCausalLM.from_pretrained(model_name)
    full_prompt = f"{prompt} Text: {text}"
    inputs = tokenizer(full_prompt, return_tensors="pt")
    outputs = model.generate(**inputs, max_length=150)
    return tokenizer.decode(outputs[0], skip_special_tokens=True)

# MarianMT for translation (if used for translation; not ideal for free-form prompts)
def use_marianmt(text, prompt):
    model_name = "Helsinki-NLP/opus-mt-en-fr"  # Example: English to French
    tokenizer = MarianTokenizer.from_pretrained(model_name)
    model = MarianMTModel.from_pretrained(model_name)
    inputs = tokenizer(text, return_tensors="pt", padding=True)
    translated = model.generate(**inputs)
    return tokenizer.decode(translated[0], skip_special_tokens=True)

# Running all models
# print("GPT-J Output:")
# print(use_gpt_j(text, prompt))
print("\nGPT-NeoX Output:")
print(use_gpt_neox(text, prompt))
# print("\nOPT Output:")
# print(use_opt(text, prompt))
# print("\nMarianMT Translation Output:")
# print(use_marianmt(text, prompt))
