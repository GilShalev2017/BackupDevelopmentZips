from transformers import AutoModelForCausalLM, AutoTokenizer

# Specify the directory where you want to save the model
local_model_path = "./gpt-j-6B"

# Create the directory if it doesn't exist
os.makedirs(local_model_path, exist_ok=True)

# Try downloading and saving the model and tokenizer
try:
    print("Downloading model and tokenizer...")
    model = AutoModelForCausalLM.from_pretrained("EleutherAI/gpt-j-6B", local_files_only=False)
    tokenizer = AutoTokenizer.from_pretrained("EleutherAI/gpt-j-6B", local_files_only=False)

    # Save the model and tokenizer locally
    model.save_pretrained(local_model_path)
    tokenizer.save_pretrained(local_model_path)

    print(f"Model and tokenizer downloaded and saved to {local_model_path}")

except Exception as e:
    print(f"An error occurred: {e}")
