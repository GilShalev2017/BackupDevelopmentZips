import whisper
import sys


#sys.stdin.reconfigure(encoding='utf-8')

audioFilePath = sys.argv[1]
model = whisper.load_model("base")
# result = model.transcribe("C:/Development/Whisper/MEDIA/WomenWorldCup.mp3", verbose=True)
result = model.transcribe(audioFilePath, verbose=True)











# #result = model.transcribe("C:/Development/Whisper/MEDIA/kan11.mp3", verbose=True)
# #result = model.transcribe("C:/Development/Whisper/MEDIA/kan11.mp3")
# # result = model.transcribe("C:/Development/Whisper/MEDIA/Arabic.mp3", verbose=True)
# # result = model.transcribe("C:/Development/Whisper/MEDIA/nbc.mp3", verbose=True)
#
# #result = model.transcribe("C:/Development/Whisper/MEDIA/Arabic.mp3", language='en', task='translate')
# #print(f"result:{result}")
#
# # import whisper
# #
# # model = whisper.load_model("base")
# # result = model.transcribe("audio.mp3")
# # print(result["text"])
#
# # import openai
# # audio_file= open("C:/actus_temp/workflow/WomenWorldCup.mp3", "rb")
# # transcript = openai.Audio.transcribe("whisper-1", audio_file)
#
# # import whisper
# # import pandas as pd
# #
# # model = whisper.load_model("base")
# # result = model.transcribe("C:/actus_temp/workflow/WomenWorldCup.mp3", verbose = True)
# # # print(result)
# # # print(result["text"])
# # print(result['segments'])
# #
# # for i, seg in enumerate(result['segments']):
# #   print(i+1, "- ", seg['text'])
#
#
#
#   # speech = pd.DataFrame.from_dict(result['segments'])
#   # speech.head()
#
# # Record the ending time
# end_time = time.time()
#
# # Calculate the elapsed time
# elapsed_time = end_time - start_time
# print(f"Elapsed time: {elapsed_time:.4f} seconds")
#
#
# # audio_file = open("C:/Development/Whisper/MEDIA/Arabic.mp3", "rb")
# # transcript = openai.Audio.translate("whisper-1", audio_file)
#
# # openai.api_key = "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"
# # audio_file = open("C:/Development/Whisper/MEDIA/Arabic.mp3", "rb")
# # transcript = openai.Audio.translate("whisper-1", audio_file,response_format="srt")
# # print(transcript)
# # print(openai.Model.list())
