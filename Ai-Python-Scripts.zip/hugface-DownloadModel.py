# from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
#
# # Download and save model locally
# model_name = "openai/whisper-small"
# model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
# tokenizer = AutoTokenizer.from_pretrained(model_name)
#
# # Save the model and tokenizer locally
# model.save_pretrained("path_to_local_model")
# tokenizer.save_pretrained("path_to_local_model")


from transformers import WhisperForConditionalGeneration, WhisperTokenizer

# Download and save the Whisper model and tokenizer locally
model_name = "openai/whisper-small"
model = WhisperForConditionalGeneration.from_pretrained(model_name)
tokenizer = WhisperTokenizer.from_pretrained(model_name)

# Save the model and tokenizer locally
model.save_pretrained("local-whisper-model")
tokenizer.save_pretrained("local-whisper-model")
