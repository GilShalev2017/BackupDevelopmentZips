from transformers import GPT2TokenizerFast, GPTNeoForCausalLM, pipeline

# //////////// FAILED ////////////////

# Load the Xenova/gpt-3 tokenizer
tokenizer = GPT2TokenizerFast.from_pretrained('Xenova/gpt-3')

# You can choose a language model for text generation
# For example, we can use GPT-Neo here
model_name = "EleutherAI/gpt-neo-2.7B"  # You can replace this with another language model
model = GPTNeoForCausalLM.from_pretrained(model_name)

# Example text and user query
text = """
Paris is the capital of France. Brad Pitt was seen in Los Angeles. The population of New York City is about 8 million.
"""
user_query = "Find all the cities mentioned in the text."

# Tokenize the user query and text using Xenova/gpt-3 tokenizer
input_text = f"Text: {text}\n\nQuery: {user_query}"
tokens = tokenizer(input_text, return_tensors="pt")

# Generate the response using a language generation model (GPT-Neo in this case)
output = model.generate(**tokens, max_length=200)

# Decode the output tokens back to text
response = tokenizer.decode(output[0], skip_special_tokens=True)

# Output the generated response
print(response)
