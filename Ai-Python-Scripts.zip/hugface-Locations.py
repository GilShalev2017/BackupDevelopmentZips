from transformers import pipeline

# Initialize the NER pipeline
ner_pipeline = pipeline("ner", model="dbmdz/bert-large-cased-finetuned-conll03-english", aggregation_strategy="simple")

# Example text to extract locations from
text = """
I recently traveled to New York City and visited the Statue of Liberty. Next month, I plan to go to Paris to see the Eiffel Tower.
"""

# Perform NER on the text
entities = ner_pipeline(text)

# Filter for only location-based entities
locations = [entity['word'] for entity in entities if entity['entity_group'] == 'LOC']

# Output the list of locations found
print("Locations found in the text:", locations)
