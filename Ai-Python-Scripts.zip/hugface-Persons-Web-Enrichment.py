from transformers import pipeline
import requests

# Initialize the NER pipeline
ner_pipeline = pipeline("ner", model="dbmdz/bert-large-cased-finetuned-conll03-english", aggregation_strategy="simple")

# Example text to extract person names from
text = """
Brad Pitt is a famous Hollywood actor. Angelina Jolie is also an accomplished director. Tom Cruise starred in the Mission Impossible movies.
"""

# Perform NER on the text
entities = ner_pipeline(text)

# Filter for only person-based entities
person_names = [entity['word'] for entity in entities if entity['entity_group'] == 'PER']

# Function to get description from Wikipedia (or any API)
def get_description_from_wikipedia(person_name):
    try:
        # Wikipedia API endpoint
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{person_name.replace(' ', '_')}"
        
        # Make the request to Wikipedia
        response = requests.get(url)
        
        # Parse the response
        if response.status_code == 200:
            data = response.json()
            return data.get("extract", "No description found")
        else:
            return "No description found"
    
    except Exception as e:
        return f"Error fetching description: {str(e)}"

# Output the list of person names and descriptions found
for person in person_names:
    description = get_description_from_wikipedia(person)
    print(f"Person: {person}, Description: {description}")
