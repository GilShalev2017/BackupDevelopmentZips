from transformers import pipeline

# Initialize a large language model pipeline from Hugging Face
# You can use "gpt-neo", "gpt-j", or other language models (e.g., "google/flan-t5-large")
# large language model (like GPT-3 or GPT-NeoX)
# model_name = "gpt2"  # You can replace this with "EleutherAI/gpt-neo-2.7B" or any other LLM. GPT-NeoX, LLaMA, or Flan-T5 gpt-3.5-turbo
# model_name = "Xenova/gpt-4o" //failed
# model_name = "EleutherAI/gpt-neo-2.7B" // failed
# model_name = "badarr/gpt-3.5-turbo" //errors missing config.json
# model_name = "gpt2" //failed
model_name = "Xenova/gpt-3"

nlp_pipeline = pipeline("text-generation", model=model_name)

# Example text to be analyzed
text = """
Paris is the capital of France. Brad Pitt was seen in Los Angeles. The population of New York City is about 8 million.
"""

# Dynamic user query
user_query = "Find all the celebrities mentioned in the text."

# Combine the text and query for context and processing
input_text = f"Text: {text}\n\nQuery: {user_query}"

# Generate the response based on the input text and query
response = nlp_pipeline(input_text, max_length=200, do_sample=True)

# Output the generated response
print(response[0]['generated_text'])
