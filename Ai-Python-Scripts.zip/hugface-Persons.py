from transformers import pipeline

# Initialize the NER pipeline
ner_pipeline = pipeline("ner", model="dbmdz/bert-large-cased-finetuned-conll03-english", aggregation_strategy="simple")

# Example text to extract person names from
text = """
Brad Pitt is a famous Hollywood actor. Angelina Jolie is also an accomplished director.
"""

# Perform NER on the text
entities = ner_pipeline(text)

# Filter for only person-based entities
person_names = [entity['word'] for entity in entities if entity['entity_group'] == 'PER']

# Output the list of person names found
print("Person names found in the text:", person_names)