# from transformers import AutoModelForCausalLM, AutoTokenizer
# import os
#
# # Specify the local path where the model is stored
# local_model_path = "./gpt-j-6B"  # Path to where the model should be saved/loaded from
#
# # Verify if the model files exist in the local directory
# if not os.path.exists(local_model_path):
#     raise FileNotFoundError(f"Directory {local_model_path} does not exist. Please download the model first.")
# else:
#     # Check for important model files
#     required_files = ["config.json", "pytorch_model.bin", "tokenizer_config.json"]
#     missing_files = [f for f in required_files if not os.path.exists(os.path.join(local_model_path, f))]
#
#     if missing_files:
#         raise FileNotFoundError(
#             f"Missing files in {local_model_path}: {', '.join(missing_files)}. Please ensure the model is downloaded correctly.")
#
#     print(f"All required model files found in {local_model_path}. Proceeding to load the model.")
#
# # Load the model and tokenizer from the local directory
# model = AutoModelForCausalLM.from_pretrained(local_model_path)
# tokenizer = AutoTokenizer.from_pretrained(local_model_path)
#
# # Print model configuration as a check
# print("Model configuration:")
# print(model.config)
#
#
# # Function to get answers from the model
# def answer_question(question, context):
#     prompt = f"Context: {context}\nQuestion: {question}\nAnswer:"
#     inputs = tokenizer(prompt, return_tensors="pt", max_length=512, truncation=True)
#
#     # Generate the answer
#     output = model.generate(**inputs, max_length=200, do_sample=True, top_p=0.95, top_k=60)
#     answer = tokenizer.decode(output[0], skip_special_tokens=True)
#
#     # Extract the answer from the prompt
#     answer = answer.split("Answer:")[-1].strip()
#
#     return answer
#
#
# # Example text and question
# context = """
# Artificial intelligence (AI) is intelligence demonstrated by machines, as opposed to the natural intelligence displayed by humans and animals.
# Leading AI textbooks define the field as the study of "intelligent agents": any device that perceives its environment and takes actions that
# maximize its chance of successfully achieving its goals.
# """
# question = "What is artificial intelligence?"
#
# # Get the answer to the question
# answer = answer_question(question, context)
#
# print(f"Question: {question}")
# print(f"Answer: {answer}")
