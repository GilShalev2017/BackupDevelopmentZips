from transformers import pipeline

# Initialize the Whisper model for transcription
transcriber = pipeline(task="automatic-speech-recognition", model="C:\\Development\\Whisper\\WhipserPython\\local-whisper-model")

# Path to the local .wav file
file_path = "C:\\Development\\MEDIA-FILES\\aboutSpeechSdk.wav"

# Perform transcription on the local file
res = transcriber(file_path)


# Function to save transcription to .srt
def save_transcription_to_srt(transcription, output_srt_path):
    with open(output_srt_path, 'w') as srt_file:
        for idx, segment in enumerate(transcription):
            # Write line number
            srt_file.write(f"{idx + 1}\n")

            # Write timestamp in SRT format
            start_time = format_time_srt(segment['start'])
            end_time = format_time_srt(segment['end'])
            srt_file.write(f"{start_time} --> {end_time}\n")

            # Write transcribed text
            srt_file.write(f"{segment['text']}\n\n")


def format_time_srt(seconds):
    """Convert seconds to SRT time format: hh:mm:ss,ms"""
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    milliseconds = (seconds - int(seconds)) * 1000
    return f"{int(hours):02}:{int(minutes):02}:{int(seconds):02},{int(milliseconds):03}"


# Assuming the transcription output contains timestamps and text
# For models like Whisper, you might need to extract or calculate 'start' and 'end' times yourself if not provided
# Example result from the ASR system
transcription = [
    {"start": 0.0, "end": 3.5, "text": res['text']}
]

# Save the transcription to an SRT file
output_srt_path = "C:\\Development\\MEDIA-FILES\\transcription_output.srt"
save_transcription_to_srt(transcription, output_srt_path)

# Confirm that the transcription was saved
print(f"Transcription saved to {output_srt_path}")
