from transformers import pipeline

text_generator = pipeline('text-generation', model="facebook/opt-125m")
# generator("What are we having for dinner?")

text = """
I recently traveled to New York City and visited the Statue of Liberty. Next month, I plan to go to Paris to see the Eiffel Tower.
"""

prompt = "Find all the locations in the text: 'I recently traveled to New York City and visited the Statue of Liberty. Next month, I plan to go to Paris to see the Eiffel Tower.'"

# Generate text based on the prompt
result = text_generator(prompt, max_length=50)

# Print the generated text
print(result[0]['generated_text'])
