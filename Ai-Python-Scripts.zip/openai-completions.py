# import openai
#
# openai.api_key = "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"
#
# output = openai.ChatCompletion.create(
#   model="gpt-3.5-turbo",
#   messages=[
#     {
#       "role": "system",
#       "content": "You will be provided with a description of a mood, and your task is to generate the CSS code for a color that matches it. Write your output in json with a single key called \"css_code\"."
#     },
#     {
#       "role": "user",
#       "content": "Blue sky at dusk."
#     }
#   ],
#   temperature=0.7,
#   max_tokens=64,
#   top_p=1
# )
#
# print(output)

import openai
openai.api_key = "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"

response = openai.ChatCompletion.create(
  model="gpt-3.5-turbo",
  messages=[
    {
      "role": "system",
      "content": "You will be provided with a description of a mood, and your task is to generate the CSS code for a color that matches it. Write your output in json with a single key called \"css_code\"."
    },
    {
      "role": "user",
      "content": "Blue sky at dusk."
    }
  ],
  temperature=0.7,
  max_tokens=64,
  top_p=1
)
print(response)