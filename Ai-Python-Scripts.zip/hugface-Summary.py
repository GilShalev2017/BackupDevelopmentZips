from transformers import pipeline

# Initialize the summarization pipeline
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

# Artificial intelligence (AI) is intelligence demonstrated by machines, as opposed to the natural intelligence displayed by humans and animals. Leading AI textbooks define the field as the study of "intelligent agents": any device that perceives its environment and takes actions that maximize its chance of successfully achieving its goals.
# Colloquially, the term "artificial intelligence" is often used to describe machines (or computers) that mimic "cognitive" functions that humans associate with the human mind, such as "learning" and "problem-solving".
# As machines become increasingly capable, tasks considered to require "intelligence" are often removed from the definition of AI, a phenomenon known as the AI effect. A quip in Tesler's Theorem says "AI is whatever hasn't been done yet." For instance, optical character recognition is frequently excluded from things considered to be AI, having become a routine technology.

# Example text you want to summarize
text = """
Caution, then caution. This thing might be too green of
sadness. And on the battlefield,
fierce fighting continues near the town of Picross.
More than 20,000 inhabitants remain in the city, despite Ukrainian
authorities continuing to evacuate the strategically important town.
British Prime Minister Keir Starmer has met his Irish counterpart
Simon Harris in Dublin, in a visit described as a reset.
Starmer's trip is the first by a British leader to Ireland in five
years, and is a further sign that the two wish to deepen relations
on economic and security matters. You know, it's a pleasure to be here,
to have this opportunity which we will take to renew the
friendship between our countries. That reset, I think,
can be meaningful. Starmer and Harris participated
in a business roundtable to explore how renewed relations
could benefit trade. The economic relationship is
worth around €120 billion, and supports thousands of jobs
on both sides of the Irish Sea. Relations between the two
countries have been strained since the UK voted in 2016 to
withdraw from the European Union. That's affected political and trade
structures of Northern Ireland, which is part of the UK.
Researchers and hydrologists surveying glaciers in Salzburg say
that the natural wonders are losing mass and size again this year.
So now installing Humvee B Hoyt is all with act nine storm
concern and shine of a little click on the ten centimeter.
In the last 25 years, the toolbox on Bleakest Glacier in Austria
lost half its mass where there used to be ice ten meters thick,
there is no bare rock. Researchers say that if the trend
continues, it's only a matter of time before the glacier disappears.
And this is the same for glaciers elsewhere,
as well as those in Tainan. Um, Mark Kane, show me a scene.
Visit the event of late cleaners flick knock scene about what does
motivate me to read this clip just so I could push it with listen um,
coma Disney song Und is skate team glitches so someone feeling
under no glitch in East race. Uh, please try to meet the rising
of the van in the next scene from neon seem. To. Make up name of the.
As the Paralympic Games come to an end.
Paris is hoping to leave its mark on how a disability is viewed
and taken into consideration. These Paralympics set a multiple
amount of records. The first one is that the highest
number of delegations participated compared to previous editions,
169 to be exact. And then the second record that
was set is that this? These were the Paralympics that
were the most covered by international media.
165 TV channels followed the events, and around 2.4 million tickets
out of 2.5 were sold. As a reminder, the highest records of
tickets for the Paralympic Games ever sold was in London in 2012.
But what remains to be seen as whether there will be a lasting
legacy when it comes to accessibility and social inclusion
for people with disabilities. At the end of August,
the president of the region has called for a massive renovation
to fix the capital's centuries old public transport system that
is almost impossible for people with disabilities to even access.
A project that could take up to 20 years and cost €15 billion,
and the feasibility of it has not even been discussed.
The party of the European Left is splitting, with one faction
aiming to form a left green and feminist party with more members
from Central and Eastern Europe. Seven left wing European parties,
including LafargeHolcim, Women's Sponge, Podemos, Nordic
Parties and Poland's regime have applied to create the European Left.
Alliance co-chair Katarina Martin says this formalizes a project
in development since 2018. The alma Square of the north of.
Three.
"""

# Perform summarization
summary = summarizer(text, max_length=130, min_length=30, do_sample=False)

# Print the summary
print(summary[0]['summary_text'])
