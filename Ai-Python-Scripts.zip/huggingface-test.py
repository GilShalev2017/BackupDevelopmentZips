# from transformers import pipeline
#
# classifier = pipeline("sentiment-analysis")
#
# results = classifier(["We are very happy to show you the 🤗 Transformers library.", "We hope you don't hate it."])
#
# for result in results:
#     print(f"label: {result['label']}, with score: {round(result['score'], 4)}")

# import torch
#
# from transformers import pipeline
#
# speech_recognizer = pipeline("automatic-speech-recognition", model="facebook/wav2vec2-base-960h")
#
# result = speech_recognizer(dataset[:4]["audio"])
#
# print([d["text"] for d in result])

# from datasets import load_dataset, Audio
#
# dataset = load_dataset("PolyAI/minds14", name="en-US", split="train")
#
# dataset = dataset.cast_column("audio", Audio(sampling_rate=speech_recognizer.feature_extractor.sampling_rate))

# model_name = "nlptown/bert-base-multilingual-uncased-sentiment"
#
# from transformers import AutoTokenizer, AutoModelForSequenceClassification
#
# model = AutoModelForSequenceClassification.from_pretrained(model_name)
#
# tokenizer = AutoTokenizer.from_pretrained(model_name)

# from transformers import AutoTokenizer, TFAutoModelForSequenceClassification
#
# model = TFAutoModelForSequenceClassification.from_pretrained(model_name)
#
# tokenizer = AutoTokenizer.from_pretrained(model_name)

# model_name = "nlptown/bert-base-multilingual-uncased-sentiment"
#
# from transformers import AutoTokenizer, TFAutoModelForSequenceClassification
#
# model = TFAutoModelForSequenceClassification.from_pretrained(model_name)
#
# tokenizer = AutoTokenizer.from_pretrained(model_name)
#
# classifier = pipeline("sentiment-analysis", model=model, tokenizer=tokenizer)
#
# classifier("Nous sommes très heureux de vous présenter la bibliothèque 🤗 Transformers.")

# from transformers import AutoTokenizer
#
# model_name = "nlptown/bert-base-multilingual-uncased-sentiment"
#
# tokenizer = AutoTokenizer.from_pretrained(model_name)
#
# encoding = tokenizer("We are very happy to show you the 🤗 Transformers library.")
#
# print(encoding)
#
# pt_batch = tokenizer(
#     ["We are very happy to show you the 🤗 Transformers library.", "We hope you don't hate it."],
#     padding=True,
#     truncation=True,
#     max_length=512,
#     return_tensors="pt",
# )
#
# tf_batch = tokenizer(
#     ["We are very happy to show you the 🤗 Transformers library.", "We hope you don't hate it."],
#     padding=True,
#     truncation=True,
#     max_length=512,
#     return_tensors="tf",
# )

# from transformers import AutoModelForSequenceClassification
#
# model_name = "nlptown/bert-base-multilingual-uncased-sentiment"
#
# pt_model = AutoModelForSequenceClassification.from_pretrained(model_name)
#
# pt_outputs = pt_model(**pt_batch)

# from torch import nn
#
# pt_predictions = nn.functional.softmax(pt_outputs.logits, dim=-1)
#
# print(pt_predictions)

# from transformers import TFAutoModelForSequenceClassification
#
# model_name = "nlptown/bert-base-multilingual-uncased-sentiment"
#
# tf_model = TFAutoModelForSequenceClassification.from_pretrained(model_name)
#
# tf_outputs = tf_model(tf_batch)

# import tensorflow as tf
#
# tf_predictions = tf.nn.softmax(tf_outputs.logits, axis=-1)
#
# tf_predictions

# from transformers import pipeline
#
# transcriber = pipeline(task="automatic-speech-recognition")
#
# res = transcriber("https://huggingface.co/datasets/Narsil/asr_dummy/resolve/main/mlk.flac")
#
# print(res)

# Initialize the speech recognition pipeline
# transcriber = pipeline(task="automatic-speech-recognition")

from transformers import pipeline

# Use OpenAI's Whisper model for transcription
transcriber = pipeline(task="automatic-speech-recognition", model="openai/whisper-large")

# Path to the local .wav file (make sure to use the correct path format for Windows)
file_path = "C:\\Development\\MEDIA-FILES\\CBS.wav"

# Perform transcription on the local file
res = transcriber(file_path)

# Print the transcription result
print(res)

# Initialize the punctuation restoration pipeline
# punctuator = pipeline("text2text-generation", model="oliverguhr/fullstop-punctuation-multilingual")
#
# # Perform punctuation restoration
# transcribed_text = res['text']
# punctuated_text = punctuator(transcribed_text)[0]['generated_text']
#
# # Print the text with punctuation added
# print(punctuated_text)