from transformers import pipeline

# /////////////////// FAILED ///////

# Initialize the model pipeline
model_name = "EleutherAI/gpt-j-6B"  # Or "EleutherAI/gpt-neox-20b"
text_generator = pipeline("text-generation", model=model_name)

# Example text and prompt
prompt = "Translate the following English text to French: 'Hello, how are you?'"

# Generate text based on the prompt
result = text_generator(prompt, max_length=50)

# Print the generated text
print(result[0]['generated_text'])
