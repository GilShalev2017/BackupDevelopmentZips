import React, { useEffect, useState } from 'react';
import { Container, Typography, List, ListItem, ListItemText, Box } from '@mui/material';

export default function App() {
  const [users, setUsers] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);

  useEffect(() => {
    // Use the Nginx proxy URLs
    const usersApi = '/api/users';
    const productsApi = '/api/products';

    // Fetch users
    fetch(usersApi)
      .then((res) => res.json())
      .then(setUsers)
      .catch(console.error);

    // Fetch products
    fetch(productsApi)
      .then((res) => res.json())
      .then(setProducts)
      .catch(console.error);
  }, []);

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Demo App
      </Typography>

      <Box sx={{ mt: 2 }}>
        <Typography variant="h6" component="h2" gutterBottom>
          Users
        </Typography>
        <List>
          {users.map((u, i) => (
            <ListItem key={i}>
              <ListItemText primary={u.name} />
            </ListItem>
          ))}
        </List>
      </Box>

      <Box sx={{ mt: 4 }}>
        <Typography variant="h6" component="h2" gutterBottom>
          Products
        </Typography>
        <List>
          {products.map((p, i) => (
            <ListItem key={i}>
              <ListItemText primary={p.name} />
            </ListItem>
          ))}
        </List>
      </Box>
    </Container>
  );
}