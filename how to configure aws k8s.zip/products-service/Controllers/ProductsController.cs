using Microsoft.AspNetCore.Mvc;
using Products.Models;

namespace Products.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private static readonly List<Product> _products = new()
    {
        new Product { Id = 101, Name = "Laptop" },
        new Product { Id = 102, Name = "Headphones" }
    };

    [HttpGet]
    public IActionResult Get()
    {
        return Ok(_products);
    }
}
