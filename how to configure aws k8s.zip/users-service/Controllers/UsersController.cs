using Microsoft.AspNetCore.Mvc;
using UsersService.Models;

namespace UsersService.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private static readonly List<User> _users = new()
    {
        new User { Id = 1, Name = "Alice" },
        new User { Id = 2, Name = "Bob" }
    };

    [HttpGet]
    public IActionResult GetUsers()
    {
        return Ok(_users);
    }
}
